package com.hlk.hlkradartool.data;

public enum LogState {
    LogStateSuccess,
    LogStateFail,
    LogStateDoing,
    LogStateProgress

}
