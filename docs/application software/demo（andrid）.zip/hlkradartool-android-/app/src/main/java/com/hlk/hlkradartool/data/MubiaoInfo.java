package com.hlk.hlkradartool.data;

public class MubiaoInfo {
    public Double jiaodu;
    public Double juli;
    public Double sudu;
    public Double targetx;
    public Double targety;

    public Double getJiaodu() {
        return jiaodu;
    }

    public void setJiaodu(Double jiaodu) {
        this.jiaodu = jiaodu;
    }

    public Double getJuli() {
        return juli;
    }

    public void setJuli(Double juli) {
        this.juli = juli;
    }

    public Double getSudu() {
        return sudu;
    }

    public void setSudu(Double sudu) {
        this.sudu = sudu;
    }

    public Double getTargetx() {
        return targetx;
    }

    public void setTargetx(Double targetx) {
        this.targetx = targetx;
    }

    public Double getTargety() {
        return targety;
    }

    public void setTargety(Double targety) {
        this.targety = targety;
    }
}
