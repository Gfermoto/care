package com.hlk.hlkradartool.data;

public class DataBean {
    String message;


    public DataBean(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
