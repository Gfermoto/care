package com.inuker.bluetooth.library.channel;

/**
 * Created by liwentian on 2017/3/20.
 */

public class Code {

    public static final int SUCCESS = 0;
    public static final int FAIL = -1;
    public static final int TIMEOUT = -2;
    public static final int BUSY = -3;
}
