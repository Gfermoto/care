package com.inuker.bluetooth.library.connect.response;

import com.inuker.bluetooth.library.model.BleGattProfile;

/**
 * Created by dingjikerbo on 2016/8/28.
 */
public interface BleConnectResponse extends BleTResponse<BleGattProfile> {
}
