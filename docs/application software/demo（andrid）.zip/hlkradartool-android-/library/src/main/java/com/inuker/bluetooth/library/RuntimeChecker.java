package com.inuker.bluetooth.library;

/**
 * Created by dingjikerbo on 2016/11/16.
 */

public interface RuntimeChecker {
    void checkRuntime();
}
