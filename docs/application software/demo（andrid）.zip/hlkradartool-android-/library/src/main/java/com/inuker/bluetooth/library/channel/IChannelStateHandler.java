package com.inuker.bluetooth.library.channel;

/**
 * Created by dingjikerbo on 17/4/15.
 */

public interface IChannelStateHandler {

	void handleState(Object... args);
}
